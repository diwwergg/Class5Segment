# Class5Segment > 2023-05-02 11:29pm
https://universe.roboflow.com/g4regtengledata/class5segment

Provided by a Roboflow user
License: CC BY 4.0

