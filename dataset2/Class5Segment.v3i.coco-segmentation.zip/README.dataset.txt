# Class5Segment > 2023-05-03 5:16am
https://universe.roboflow.com/g4regtengledata/class5segment

Provided by a Roboflow user
License: CC BY 4.0

